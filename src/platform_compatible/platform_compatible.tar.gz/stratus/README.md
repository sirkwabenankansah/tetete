# Plarform Compatible Ansible

This directory contains ansible code that is designed to run on the platform ansible controller.
